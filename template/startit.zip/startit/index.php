<?php get_header(); ?>

<h1>Welcome Boss</h1>

<?php get_footer(); ?>