<?php get_header(); ?>

<h1>Welcome Home Boss</h1>

<?php get_footer(); ?>